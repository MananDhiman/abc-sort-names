# ABC Sort Names: Privacy Policy
Welcome to the ABC Sort Names App for Android

This is an open source app developed by Manan Dhiman. The source code is available at Github at https://github.com/MananDhiman/abc-sort-names.
The app is also available on Google Play Store.

I declare that to the best of my knowledge and belief, that I have not programmed the app to collect any personally identifiable information.
All the data used or created by the app is saved locally and never sent to any server. This can be easily deleted by clearing the app's data in settings.

The app requires no explicit permissions to run. And the data stored is the number of attended classes, and the total number of classes. This data is manually entered by the user.

If any issues, contact me at hello@manandhiman.com
